// Integration example — App #003 — QR & Barcode Studio
//
// This file is NOT copied into the host automatically. Call this once
// during app bootstrap (e.g. in the same place App #002's analytics
// bridge is registered) using the REAL host analytics hook:
//
//   src/core/hooks/useAnalytics.ts  →  trackFeature(label, metadata?)

import { trackFeature } from '@core/hooks/useAnalytics';
import { setAnalyticsHandler } from '@apps/qr-barcode-studio';

export function registerQrBarcodeStudioAnalytics(): void {
  setAnalyticsHandler((eventName, payload) => {
    trackFeature(eventName, {
      app: 'qr_barcode_studio',
      ...payload,
    });
  });
}

// Note: payloads from App #003 never include full decoded QR/barcode
// values, Wi-Fi passwords, email bodies, or vCard personal data — only
// safe metadata such as type/format/source/action.
