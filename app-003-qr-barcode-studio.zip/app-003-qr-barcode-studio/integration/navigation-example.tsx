// Integration example — App #003 — QR & Barcode Studio
//
// This file is NOT copied into the host automatically. It shows the card
// snippet to add into the host's real home page:
//
//   src/apps/home/HomePage.tsx
//
// Do NOT edit HomePage.tsx directly from this package — copy the relevant
// JSX below into the existing apps grid, next to the App #001 and App #002
// cards, using whatever card component HomePage.tsx already uses for those.

import React from 'react';
import { ROUTES } from '@core/config/constants';

// Illustrative only — replace <ExistingAppCard> with whatever card
// component src/apps/home/HomePage.tsx already renders for App #001/#002.
export function QrBarcodeStudioHomeCardExample() {
  return (
    <ExistingAppCard
      title="App #003"
      name="QR & Barcode Studio"
      description="Create and scan QR codes and barcodes privately in your browser."
      tags={['QR Generator', 'Barcode', 'Scanner', 'Wi-Fi QR']}
      buttonLabel="Open tool"
      href={ROUTES.qrBarcodeStudio}
    />
  );
}

// Placeholder type so this file type-checks standalone. The host's real
// ExistingAppCard component already exists in HomePage.tsx — remove this
// declaration when copying the JSX above into the real file.
declare function ExistingAppCard(props: {
  title: string;
  name: string;
  description: string;
  tags: string[];
  buttonLabel: string;
  href: string;
}): JSX.Element;
