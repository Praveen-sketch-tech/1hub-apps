// Integration example — App #003 — QR & Barcode Studio
//
// This file is NOT copied into the host automatically. It shows the change
// to make in the host's real router file:
//
//   src/core/routes/AppRoutes.tsx
//
// 1. Add the import alongside the App #001 / App #002 imports:
//
//   import { QrBarcodeStudioPage } from '@apps/qr-barcode-studio';
//
// 2. Add the route alongside the existing public app routes. It must NOT
//    be nested inside <ProtectedRoute> — login is not required.
//
//   <Route
//     path={ROUTES.qrBarcodeStudio}
//     element={<QrBarcodeStudioPage />}
//   />
//
// Below is a minimal illustrative snippet (not a full router file) showing
// where the new route slots in relative to the existing ones.

import React from 'react';
import { Routes, Route } from 'react-router-dom';
import { ROUTES } from '@core/config/constants';
import { QrBarcodeStudioPage } from '@apps/qr-barcode-studio';

export function AppRoutesExampleFragment() {
  return (
    <Routes>
      {/* ...existing routes for App #001 (smart-image-tools) and
          App #002 (smart-pdf-tools) stay exactly as they are... */}

      <Route path={ROUTES.qrBarcodeStudio} element={<QrBarcodeStudioPage />} />

      {/* ...existing auth/protected/admin routes stay exactly as they are... */}
    </Routes>
  );
}
