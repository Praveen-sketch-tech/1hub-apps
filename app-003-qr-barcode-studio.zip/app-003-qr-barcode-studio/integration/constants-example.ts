// Integration example — App #003 — QR & Barcode Studio
//
// This file is NOT copied into the host automatically. It shows the entry
// to add to the host's real routes file:
//
//   src/core/config/constants.ts
//
// Add the `qrBarcodeStudio` key to the existing ROUTES object (do not
// replace the whole object — merge this key in alongside the App #001 and
// App #002 entries).

export const ROUTES_EXAMPLE = {
  // ...existing routes (smartImageTools, smartPdfTools, etc.) stay as-is
  qrBarcodeStudio: '/apps/qr-barcode-studio',
};

// This route is PUBLIC. Do not wrap it in ProtectedRoute — login is not
// required for App #003.
