# App #003 — QR & Barcode Studio

A standalone drop-in integration package for the **1 Hub Apps** project.
Generates and scans QR codes and barcodes entirely in the browser — no
login, no paid API, no server-side processing, no cloud upload.

This package is **integration-only**. It does not modify or include the
1 Hub Apps base project. It is designed to be copied into:

```
src/apps/qr-barcode-studio/
```

---

## 1. What's in this ZIP

```
app-003-qr-barcode-studio/
├── src/
│   └── apps/
│       └── qr-barcode-studio/      ← copy this folder into your repo
├── integration/                    ← reference snippets only, not auto-applied
│   ├── route-example.tsx
│   ├── constants-example.ts
│   ├── navigation-example.tsx
│   └── analytics-bridge-example.ts
├── README.md                       ← this file
└── PACKAGE-CONTENTS.txt
```

No `node_modules`, `dist`, `.env`, or secrets are included.

---

## 2. Install dependencies

Run this from the root of the 1 Hub Apps repo, **after** copying the
`qr-barcode-studio` folder in (see step 3):

```bash
npm install qrcode@1.5.4 jsbarcode@3.12.3 @zxing/browser@0.2.1 @zxing/library@0.23.0
npm install --save-dev @types/qrcode@1.5.6
```

Notes:

- `jsbarcode@3.12.3` ships its own TypeScript types, so no separate
  `@types/jsbarcode` package is required.
- `@zxing/browser` and `@zxing/library` ship their own TypeScript types.
- All four packages are framework-agnostic (no React dependency of their
  own), so they impose no React-version constraint — verified compatible
  with **React 18**, **TypeScript**, and **Vite 5**. None require React 19
  or a newer Vite major version.

---

## 3. Copy the feature into your repo

```bash
cp -r app-003-qr-barcode-studio/src/apps/qr-barcode-studio  <your-repo>/src/apps/qr-barcode-studio
```

Do **not** copy the `integration/` folder into `src/` — those files are
reference snippets for you to merge into the real host files by hand.

---

## 4. Route integration

Add one entry to the existing `ROUTES` object in
`src/core/config/constants.ts` (see `integration/constants-example.ts`):

```ts
qrBarcodeStudio: '/apps/qr-barcode-studio',
```

Then, in `src/core/routes/AppRoutes.tsx` (see `integration/route-example.tsx`),
add the import and route alongside the App #001 / App #002 entries:

```tsx
import { QrBarcodeStudioPage } from '@apps/qr-barcode-studio';

<Route path={ROUTES.qrBarcodeStudio} element={<QrBarcodeStudioPage />} />
```

**This route must be public.** Do not wrap it in `ProtectedRoute` — login
is not required for App #003.

---

## 5. Home page card

See `integration/navigation-example.tsx` for a card snippet to add to
`src/apps/home/HomePage.tsx`, using whatever card component that page
already renders for App #001 / App #002:

- Title: **App #003**
- Name: **QR & Barcode Studio**
- Description: *Create and scan QR codes and barcodes privately in your browser.*
- Tags: `QR Generator`, `Barcode`, `Scanner`, `Wi-Fi QR`
- Button: **Open tool** → `ROUTES.qrBarcodeStudio`

`HomePage.tsx` is not modified by this package — copy the JSX in by hand.

---

## 6. Analytics integration

App #003 never imports Supabase or `trackFeature` directly. It exposes a
host-independent `setAnalyticsHandler()` (see `integration/analytics-bridge-example.ts`).
Call this once at app bootstrap:

```ts
import { trackFeature } from '@core/hooks/useAnalytics';
import { setAnalyticsHandler } from '@apps/qr-barcode-studio';

setAnalyticsHandler((eventName, payload) => {
  trackFeature(eventName, { app: 'qr_barcode_studio', ...payload });
});
```

Events fired: `qr_generated`, `qr_downloaded`, `qr_logo_added`,
`barcode_generated`, `barcode_downloaded`, `scanner_camera_started`,
`scanner_camera_stopped`, `qr_scanned`, `barcode_scanned`,
`scan_result_copied`, `scan_url_opened`, `print_used`.

**Privacy:** payloads only ever contain safe metadata (type, format,
source, action). They never contain the full decoded QR/barcode value,
Wi-Fi passwords, email bodies, or vCard personal data.

---

## 7. Feature overview

- **QR Generator** — URL, Text, Phone, Email, SMS, Wi-Fi, vCard/Contact.
  Customizable size, colors, margin, error-correction level, and an
  optional center logo (auto-forces `H` error correction). Live debounced
  preview. Download as high-resolution PNG (up to 2048px) or SVG. Print.
- **Barcode Generator** — CODE128, CODE39, EAN-13, EAN-8, UPC-A, ITF-14,
  with format-aware validation, customizable dimensions/colors, PNG/SVG
  download, and print.
- **Scanner** — Camera (rear-camera preferred on mobile, explicit
  Start/Stop, full cleanup) and Upload Image tabs, decoding QR codes and
  common 1D barcodes fully client-side via `@zxing/browser`.
- **Scan result** — Copy, Open URL (only on explicit click,
  `target="_blank" rel="noopener noreferrer"`), context-aware actions for
  `tel:`, `mailto:`, `sms:`, and Scan another.
- **Scan history** — last 10 scans, stored in `localStorage`, with
  Copy/Remove/Clear. Never sent to Supabase or any server.
- 100% client-side. No uploads of QR/barcode content, camera video,
  scanned images, or scan history to any server.

---

## 8. Manual testing checklist

**QR Generator**
- [ ] URL — valid/invalid input, protocol auto-normalization
- [ ] Text — arbitrary text, character count
- [ ] Phone — `tel:` payload
- [ ] Email — address, optional subject/message
- [ ] SMS — phone + message
- [ ] Wi-Fi — WPA/WEP/None, hidden toggle, special-character escaping
- [ ] vCard — all fields, decodes correctly in a contacts app
- [ ] Logo upload — centered, aspect-ratio preserved, forces EC level H
- [ ] Color customization — foreground/background
- [ ] Error correction levels L/M/Q/H
- [ ] PNG download at 512/1024/2048
- [ ] SVG download
- [ ] Print

**Barcode Generator**
- [ ] CODE128, CODE39, EAN-13, EAN-8, UPC-A, ITF-14
- [ ] Validation messages for invalid input per format
- [ ] PNG download
- [ ] SVG download
- [ ] Print

**Scanner**
- [ ] QR via camera
- [ ] Barcode via camera
- [ ] QR via uploaded image
- [ ] Barcode via uploaded image
- [ ] Camera permission denied → clear error
- [ ] No camera available → clear error
- [ ] No code found in image → clear message
- [ ] Stop Scanner button releases the camera
- [ ] Camera releases automatically on unmount / tab switch

**Other**
- [ ] Copy result to clipboard
- [ ] Safe URL open (new tab, `noopener noreferrer`, requires click)
- [ ] Scan history persists across reloads, Remove/Clear work
- [ ] Print produces a clean, UI-free layout
- [ ] Mobile layout (stacked, touch-friendly buttons)
- [ ] Dark mode and light mode

---

## 9. Known limitations

- **Camera on `http://localhost`:** most Chromium/Firefox browsers treat
  `localhost` as a secure context and allow camera access in dev even over
  HTTP. Camera access on any **other** non-HTTPS host will be blocked by
  the browser — this is a browser platform restriction, not a bug in this
  package. Production deployments must be served over HTTPS.
- **SVG barcode + PNG generation:** the PNG barcode download is rasterized
  from the generated SVG at 3x scale via an offscreen canvas, rather than
  drawn natively at bitmap resolution, since JsBarcode's canvas renderer
  and SVG renderer can produce slightly different metrics. This keeps the
  two downloads visually consistent.
- **Logo + very high data density:** combining a large logo with a very
  long encoded payload (e.g. a long vCard) and a high error-correction
  level can occasionally produce a QR code that is hard for some scanners
  to read. The UI keeps the logo capped at a safe size ratio and shows a
  warning, but physical print quality and scanner quality still matter.
- **iOS Safari camera quirks:** some older iOS Safari versions only expose
  camera switching after the first permission grant; the rear-camera
  preference is applied on a best-effort basis via device label matching.
- No barcode formats beyond the six listed are implemented in v1
  (e.g. Code 93, PDF417, Data Matrix, Aztec) — these can be added later by
  extending `lib/barcodeGenerator.ts` and `lib/validators.ts`.

---

## 10. Validation / build status

This package was audited and validated inside an **offline sandbox**
(no network access to npm), so a full dependency-accurate `npm install`
+ Vite production build could not be executed as part of producing this
ZIP. To validate as thoroughly as possible without network access:

1. **Full manual import audit** — every relative import in every `.ts`/
   `.tsx` file was checked against the real file tree (see file tree in
   section 1). No `../` mistakes like the ones that broke App #002 are
   present; components/hooks/lib reference `../types` and each other
   correctly, and the root page/`index.ts` reference `./components/...`,
   `./lib/...`, `./hooks/...`, and `./qr-barcode-studio.css` correctly.
2. **Structural TypeScript compile** — the entire `src/apps/qr-barcode-studio`
   tree was compiled with `tsc --noEmit` under `strict` mode (JSX:
   `react-jsx`), using local ambient type stubs for `react`, `qrcode`,
   `jsbarcode`, `@zxing/browser`, and `@zxing/library` (since those
   packages could not be downloaded in this sandbox). **Result: 0 errors.**
   This confirms every import resolves, every exported symbol matches its
   usage, and there are no syntax or structural TypeScript errors.
3. **API surface verification** — the `qrcode`, `jsbarcode`, and
   `@zxing/browser`/`@zxing/library` API calls used in `lib/qrGenerator.ts`,
   `lib/barcodeGenerator.ts`, and `lib/scanner.ts` were cross-checked
   against each package's published documentation and current npm listing
   to confirm method names, option shapes, and versions.

**What this does *not* replace:** a real `npm install` in the actual host
project followed by `vite build` and `tsc --noEmit` against the real
published `@types/react`, `qrcode`, `jsbarcode`, and `@zxing/*` type
packages. Please run that once after copying this package in — given the
clean structural compile above, no import or structural errors are
expected, but real published types may surface minor option-shape
mismatches that a stub-based check cannot catch. Recommended commands
after copying in:

```bash
npm install
npx tsc --noEmit
npm run build
```

---

## 11. Security / privacy summary

- All QR/barcode generation and scanning happens locally in the browser.
- No QR/barcode content, camera video, uploaded scanner images, or scan
  history is ever sent to a server.
- Analytics payloads contain only safe metadata — never full decoded
  values, Wi-Fi passwords, email bodies, or vCard personal data.
- Scanned URLs are never opened automatically — opening requires an
  explicit click on "Open URL", using `target="_blank" rel="noopener noreferrer"`.
