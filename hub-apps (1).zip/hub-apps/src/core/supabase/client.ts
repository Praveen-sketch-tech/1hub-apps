import { createClient } from '@supabase/supabase-js'
import { env } from '@core/config/env'
import type { Database } from './types'

// Single shared Supabase client for the whole app.
// Import this everywhere instead of creating new clients.
//
// The Database generic below relies on src/core/supabase/types.ts exposing
// Tables/Views/Functions/Enums/CompositeTypes and Row/Insert/Update/
// Relationships on every table. If you ever see query results resolve to
// `never` again, that shape is almost always the cause — check types.ts
// before removing this generic.
export const supabase = createClient<Database>(env.supabaseUrl, env.supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true
  }
})
